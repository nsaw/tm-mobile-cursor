# Thoughtmarks React Native/Expo Deployment Guide

## Prerequisites

1. **Node.js 18+** and npm/yarn
2. **Expo CLI**: `npm install -g @expo/cli`
3. **React Native CLI**: `npm install -g react-native-cli`
4. **Development Environment**:
   - For iOS: Xcode 14+ (macOS only)
   - For Android: Android Studio with SDK 33+

## Initial Setup

### 1. Install Dependencies
```bash
cd export-packages/react-native-expo
npm install
```

### 2. Environment Configuration
Create `.env` file in the root directory:
```env
EXPO_PUBLIC_API_BASE_URL=https://your-backend-url.com
EXPO_PUBLIC_FIREBASE_API_KEY=your-firebase-api-key
EXPO_PUBLIC_FIREBASE_PROJECT_ID=your-firebase-project-id
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
EXPO_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abcdef
EXPO_PUBLIC_OPENAI_API_KEY=your-openai-api-key
EXPO_PUBLIC_GOOGLE_CLIENT_ID=your-google-oauth-client-id
EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID=your-google-ios-client-id
EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID=your-google-android-client-id
```

### 3. Firebase Configuration
1. Create a new Firebase project
2. Enable Authentication with Google and Apple Sign-In
3. Add iOS and Android apps to your Firebase project
4. Download configuration files:
   - `google-services.json` for Android
   - `GoogleService-Info.plist` for iOS
5. Place configuration files in the appropriate directories

## Development

### Start Development Server
```bash
# Start Expo development server
npm start

# Run on iOS simulator
npm run ios

# Run on Android emulator
npm run android

# Run on web browser
npm run web
```

### Testing on Physical Devices
1. Download Expo Go app on your mobile device
2. Scan the QR code from the development server
3. Test all features including authentication and voice recording

## Backend Integration

### API Endpoint Conversion
The current web application uses these endpoints that need to be available:

**Authentication:**
- `POST /api/auth/signin`
- `POST /api/auth/signup`
- `POST /api/auth/google`
- `POST /api/auth/apple`

**Thoughtmarks:**
- `GET /api/thoughtmarks`
- `POST /api/thoughtmarks`
- `PATCH /api/thoughtmarks/:id`
- `DELETE /api/thoughtmarks/:id`
- `POST /api/thoughtmarks/:id/toggle-pin`

**Bins:**
- `GET /api/bins`
- `POST /api/bins`
- `PATCH /api/bins/:id`
- `DELETE /api/bins/:id`

**AI Features:**
- `POST /api/ai/insights`
- `POST /api/ai/categorize`
- `POST /api/ai/summarize`

### CORS Configuration
Update your backend to allow requests from mobile app:
```javascript
// Express.js example
app.use(cors({
  origin: ['http://localhost:19000', 'https://your-app.exp.direct'],
  credentials: true
}));
```

## Build for Production

### 1. Configure app.json
Update `app.json` with your app details:
```json
{
  "expo": {
    "name": "Thoughtmarks",
    "slug": "thoughtmarks-mobile",
    "ios": {
      "bundleIdentifier": "com.yourcompany.thoughtmarks"
    },
    "android": {
      "package": "com.yourcompany.thoughtmarks"
    }
  }
}
```

### 2. EAS Build Setup
```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo account
eas login

# Configure EAS build
eas build:configure

# Build for iOS
eas build --platform ios

# Build for Android
eas build --platform android
```

### 3. App Store Deployment

#### iOS App Store
1. Create App Store Connect account
2. Create new app in App Store Connect
3. Upload build using EAS or Xcode
4. Configure app metadata and screenshots
5. Submit for review

#### Google Play Store
1. Create Google Play Console account
2. Create new app in Play Console
3. Upload APK/AAB file from EAS build
4. Configure store listing and screenshots
5. Submit for review

## Authentication Setup

### Google OAuth
1. Go to Google Cloud Console
2. Create OAuth 2.0 credentials for:
   - Web application (for development)
   - iOS application
   - Android application
3. Add redirect URIs for Expo development

### Apple Sign-In
1. Enable Sign in with Apple in your Apple Developer account
2. Configure App ID with Sign in with Apple capability
3. Create Service ID for web authentication

## Push Notifications

### Setup Expo Notifications
```bash
# Configure push notifications
expo install expo-notifications

# For iOS: Configure APNs
# For Android: Configure FCM
```

### Implementation
```typescript
import * as Notifications from 'expo-notifications';

// Request permissions
const { status } = await Notifications.requestPermissionsAsync();

// Get push token
const token = await Notifications.getExpoPushTokenAsync();
```

## Analytics and Monitoring

### Expo Application Services
- Error tracking with Sentry
- Performance monitoring
- Crash reporting

### Custom Analytics
Integrate with your existing analytics:
```typescript
// Example: Custom event tracking
const trackEvent = (eventName: string, properties: any) => {
  // Send to your analytics service
};
```

## Testing Strategy

### Unit Tests
```bash
# Install testing dependencies
npm install --save-dev jest @testing-library/react-native

# Run tests
npm test
```

### E2E Testing
```bash
# Install Detox for E2E testing
npm install --save-dev detox

# Configure and run E2E tests
detox test
```

## Performance Optimization

### Bundle Size Optimization
- Use Expo's tree shaking
- Implement code splitting
- Optimize images and assets

### Memory Management
- Implement proper cleanup in useEffect hooks
- Use FlatList for large datasets
- Optimize image loading

## Deployment Checklist

- [ ] Environment variables configured
- [ ] Firebase authentication working
- [ ] Backend API endpoints accessible
- [ ] Push notifications configured
- [ ] App Store/Play Store accounts created
- [ ] App icons and splash screens added
- [ ] Privacy policy and terms of service linked
- [ ] Analytics and crash reporting enabled
- [ ] Beta testing completed
- [ ] Performance testing on various devices

## Troubleshooting

### Common Issues

**Build Failures:**
- Check Expo SDK compatibility
- Verify all dependencies are compatible
- Clear cache: `expo r -c`

**Authentication Issues:**
- Verify OAuth client IDs
- Check redirect URIs
- Ensure Firebase configuration is correct

**API Connection:**
- Verify backend URL in environment variables
- Check CORS configuration
- Test API endpoints directly

### Support Resources
- [Expo Documentation](https://docs.expo.dev/)
- [React Navigation Docs](https://reactnavigation.org/)
- [Firebase Documentation](https://firebase.google.com/docs)

## Cost Estimates

### Development Costs
- Apple Developer Program: $99/year
- Google Play Console: $25 one-time fee
- Expo EAS Build: Free tier available, paid plans from $29/month

### Infrastructure Costs
- Backend hosting (existing)
- Firebase usage (Authentication + Storage)
- Push notification services (Expo free tier)

---

This deployment guide provides a complete path from development to production for the Thoughtmarks React Native/Expo application.