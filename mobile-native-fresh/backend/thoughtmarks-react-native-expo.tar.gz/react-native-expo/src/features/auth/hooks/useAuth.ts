import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Google from 'expo-auth-session/providers/google';
import * as AppleAuthentication from 'expo-apple-authentication';
import { apiService } from '../../../services/api';
import type { User, AuthState } from '../../../types';

const STORAGE_KEYS = {
  USER: '@thoughtmarks_user',
  TOKEN: '@thoughtmarks_token',
  REFRESH_TOKEN: '@thoughtmarks_refresh_token',
};

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    loading: true,
    guestMode: false,
  });

  // Google OAuth setup
  const [request, response, promptAsync] = Google.useAuthRequest({
    expoClientId: process.env.EXPO_PUBLIC_GOOGLE_CLIENT_ID,
    iosClientId: process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID,
    androidClientId: process.env.EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID,
    webClientId: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID,
  });

  // Initialize auth state from storage
  useEffect(() => {
    initializeAuth();
  }, []);

  // Handle Google OAuth response
  useEffect(() => {
    if (response?.type === 'success') {
      handleGoogleAuthSuccess(response.authentication?.accessToken);
    }
  }, [response]);

  const initializeAuth = async () => {
    try {
      const [storedUser, storedToken] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.USER),
        AsyncStorage.getItem(STORAGE_KEYS.TOKEN),
      ]);

      if (storedUser && storedToken) {
        const user = JSON.parse(storedUser);
        await validateAndSetUser(user, storedToken);
      } else {
        setAuthState(prev => ({ ...prev, loading: false, guestMode: true }));
      }
    } catch (error) {
      console.error('Failed to initialize auth:', error);
      setAuthState(prev => ({ ...prev, loading: false, guestMode: true }));
    }
  };

  const validateAndSetUser = async (user: User, token: string) => {
    try {
      // Validate token with backend
      const response = await apiService.validateToken(token);
      if (response.success && response.data) {
        setAuthState({
          user: response.data,
          isAuthenticated: true,
          loading: false,
          guestMode: false,
        });
      } else {
        await clearAuthData();
        setAuthState(prev => ({ ...prev, loading: false, guestMode: true }));
      }
    } catch (error) {
      console.error('Token validation failed:', error);
      await clearAuthData();
      setAuthState(prev => ({ ...prev, loading: false, guestMode: true }));
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      setAuthState(prev => ({ ...prev, loading: true }));
      
      const response = await apiService.signIn(email, password);
      if (response.success && response.data) {
        await storeAuthData(response.data.user, response.data.token);
        setAuthState({
          user: response.data.user,
          isAuthenticated: true,
          loading: false,
          guestMode: false,
        });
        return response.data.user;
      } else {
        throw new Error(response.error || 'Sign in failed');
      }
    } catch (error) {
      setAuthState(prev => ({ ...prev, loading: false }));
      throw error;
    }
  };

  const signUp = async (email: string, password: string, firstName?: string, lastName?: string) => {
    try {
      setAuthState(prev => ({ ...prev, loading: true }));
      
      const response = await apiService.signUp(email, password, firstName, lastName);
      if (response.success && response.data) {
        await storeAuthData(response.data.user, response.data.token);
        setAuthState({
          user: response.data.user,
          isAuthenticated: true,
          loading: false,
          guestMode: false,
        });
        return response.data.user;
      } else {
        throw new Error(response.error || 'Sign up failed');
      }
    } catch (error) {
      setAuthState(prev => ({ ...prev, loading: false }));
      throw error;
    }
  };

  const signInWithGoogle = async () => {
    try {
      setAuthState(prev => ({ ...prev, loading: true }));
      const result = await promptAsync();
      if (result.type === 'success') {
        // Google auth success will be handled by useEffect
        return;
      } else {
        setAuthState(prev => ({ ...prev, loading: false }));
        throw new Error('Google sign in was cancelled');
      }
    } catch (error) {
      setAuthState(prev => ({ ...prev, loading: false }));
      throw error;
    }
  };

  const handleGoogleAuthSuccess = async (accessToken?: string) => {
    if (!accessToken) {
      setAuthState(prev => ({ ...prev, loading: false }));
      throw new Error('No access token received from Google');
    }

    try {
      const response = await apiService.signInWithGoogle(accessToken);
      if (response.success && response.data) {
        await storeAuthData(response.data.user, response.data.token);
        setAuthState({
          user: response.data.user,
          isAuthenticated: true,
          loading: false,
          guestMode: false,
        });
      } else {
        throw new Error(response.error || 'Google sign in failed');
      }
    } catch (error) {
      setAuthState(prev => ({ ...prev, loading: false }));
      throw error;
    }
  };

  const signInWithApple = async () => {
    try {
      setAuthState(prev => ({ ...prev, loading: true }));
      
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      const response = await apiService.signInWithApple(credential);
      if (response.success && response.data) {
        await storeAuthData(response.data.user, response.data.token);
        setAuthState({
          user: response.data.user,
          isAuthenticated: true,
          loading: false,
          guestMode: false,
        });
        return response.data.user;
      } else {
        throw new Error(response.error || 'Apple sign in failed');
      }
    } catch (error) {
      setAuthState(prev => ({ ...prev, loading: false }));
      if (error.code === 'ERR_REQUEST_CANCELED') {
        throw new Error('Apple sign in was cancelled');
      }
      throw error;
    }
  };

  const signOut = async () => {
    try {
      await clearAuthData();
      setAuthState({
        user: null,
        isAuthenticated: false,
        loading: false,
        guestMode: true,
      });
    } catch (error) {
      console.error('Sign out failed:', error);
      throw error;
    }
  };

  const storeAuthData = async (user: User, token: string) => {
    await Promise.all([
      AsyncStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user)),
      AsyncStorage.setItem(STORAGE_KEYS.TOKEN, token),
    ]);
  };

  const clearAuthData = async () => {
    await Promise.all([
      AsyncStorage.removeItem(STORAGE_KEYS.USER),
      AsyncStorage.removeItem(STORAGE_KEYS.TOKEN),
      AsyncStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN),
    ]);
  };

  return {
    ...authState,
    signIn,
    signUp,
    signInWithGoogle,
    signInWithApple,
    signOut,
  };
};