npm run audit:clickables

# Verifies:
- All buttons, links, and touchables have:
  - `accessibilityLabel`
  - `accessible={true}`
  - `accessibilityRole`
