# Git Hygiene Notes

- PHASE 1: Rename `main` branch to `ver1.2.1`
- PHASE 2: Tag recovery checkpoints with `vX.Y.Z_rollback`
- PHASE 3: Script: `scripts/branch-audit.sh` for mapping
