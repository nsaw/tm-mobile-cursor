# ModalSpecCard Layout Override Notes

- Equal height card layout targeted
- Next arrow repositioning issue traced to max-height constraint
- Title/pagination/icon vertical alignment tuned
