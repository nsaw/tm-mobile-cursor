// src-nextgen/features/index.ts
// Placeholder for nextgen features

export {}; 