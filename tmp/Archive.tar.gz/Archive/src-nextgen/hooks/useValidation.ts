import { useValidation as useValidationUtils } from '../utils/validation';

export function useValidation() {
  return useValidationUtils();
} 