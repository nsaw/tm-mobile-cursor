// src-nextgen/hooks/index.ts
// Placeholder for nextgen hooks

export * from './useAuth';
export * from './useValidation';
export * from './useAccessibility'; 