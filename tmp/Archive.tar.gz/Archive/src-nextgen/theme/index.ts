// src-nextgen/theme/index.ts
export { ThemeProvider, useTheme, type ThemeTokens } from './ThemeProvider'; 