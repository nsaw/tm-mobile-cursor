// src-nextgen/navigation/index.ts
export { NavigationProvider, useNavigation, type NavigationState, type NavigationContextType } from './NavigationProvider'; 