import React from 'react';

export const TopBarShellSlot = () => {
  return <></>; // placeholder slot for top bar injection
}; 