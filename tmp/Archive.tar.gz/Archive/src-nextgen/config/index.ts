// src-nextgen/config/index.ts
// Placeholder for nextgen config

export {}; 