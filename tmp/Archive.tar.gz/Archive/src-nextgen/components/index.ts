// src-nextgen/components/index.ts
// Placeholder for nextgen components

export {}; 