// src-nextgen/services/index.ts
// Placeholder for nextgen services

export * from './authService';
export * from './userService';
export * from './analyticsService';
export * from './errorService'; 